// src/App.jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import ResponsiveWrapper from './component/ResponsiveWrapper';

import ContactPage from './component/Home';
import Header from './component/Header';
import Home from './component/Home';
import Features from './component/Features';
import Product from './component/Product';
import Solar from './component/Solar';
import About from './component/About';
import FAQ from './component/FAQ';

function App() {
  return (
    <Router>
      
      <ResponsiveWrapper>
        <Routes>
          
          <Route path="/" element={<Home />} />
          <Route path="/featuers" element={<Features />} />
          <Route path="/product" element={<Product />} />
          <Route path="/solar" element={<Solar />} />
          <Route path="/about" element={<About />} />
          <Route path="/faq" element={<FAQ />} />
        </Routes>
      </ResponsiveWrapper>
    </Router>
  );
}

export default App;
