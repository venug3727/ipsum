import React from "react";
import "./FAQ.css";
import Header from "./Header";
import Footer from "./Footer";
import price from "./images/image copy 2.png";
import head from "./images/image copy 3.png";
import tic from "./images/image copy 4.png";

function FAQ() {
  return (
    <>
      <Header />
      <div className="flex-col mt-10 ">
        <div className="flex gap-5 items-center">
          <div className="text-2xl p-8 font-bold ">
            <h1>Create A Beautiful And Economical Environment</h1>
          </div>
          <div className="text-sm font-serif ">
            <p>
              We are the best solar energy provider in Southeast Asia with more
              than 2 million customers per year
            </p>
            <button className="p-2 bg-yellow-500 rounded-3xl m-2">
              Learn more
            </button>
          </div>
        </div>
        <div className="bg-slate-400  md:h-56 md:w-full rounded-3xl sm:w-80 h-36 rounded-3xl items-center justify-center"></div>
        <div className="flex sm:flex-wrap md:flex-nowrap mb-10">
          <div className="flex justify-center pl-7 pr-28 flex-col mt-10 ml-10 h-72 w-96 bg-white rounded-3xl">
            <div className="">
              <img className="h-10 w-10 " src={price} alt="" />
            </div>
            <div className="font-bold mt-5 text-lg">
              <h1>Transparent Pricing</h1>
            </div>
            <div className="mt-5 text-sm ">
              <p>
                The price is transparent and also competes with other flight
                services
              </p>
            </div>
          </div>
          <div className="flex justify-center  pl-7 pr-28 flex-col mt-10 ml-10 h-72 w-96 bg-white rounded-3xl">
            <div className="bg-yellow-500 h-15 w-10 items-center   rounded-3xl">
              <img className="  " src={head} alt="" />
            </div>
            <div className="font-bold mt-5 text-lg">
              <h1>Custemer service 24/7</h1>
            </div>
            <div className="mt-5 text-sm ">
              <p>
                You can do consultations and ask questions 24 hours without
                stopping
              </p>
            </div>
          </div>
          <div className="flex justify-center pl-7 pr-28 flex-col mt-10 ml-10 h-72 w-96 bg-white rounded-3xl">
            <div className="">
              <img className="h-10 w-10 " src={tic} alt="" />
            </div>
            <div className="font-bold mt-5 text-lg">
              <h1>Safety number 1</h1>
            </div>
            <div className="mt-5 text-sm ">
              <p>
                The safety of your goods guaranteed because we have quality
                control
              </p>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}

export default FAQ;
