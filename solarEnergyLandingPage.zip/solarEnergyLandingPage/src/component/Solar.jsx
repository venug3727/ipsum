import React from "react";
import './Solar.css';
function Solar() {
  return (
    <>
    <h1>Solar page</h1>
    
    </>
  );
}

export default Solar;
