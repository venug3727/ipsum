import React from "react";
import Footer from "./Footer";
import Header from "./Header";
import rate from "./images/image copy 5.png";
function Product() {
  return (
    <>
      <Header />
      <div className="bg-slate-50">
        <div className="flex m-10 flex-col items-center  justify-center">
          <div className="">
            <h1 className="text-2xl font-bold text-center leading-relaxed m-6">
              There Are Many Types Of Solar <br />
              Panel That You Can Use
            </h1>
            <p className="text-center text-sm m-5">
              There is a huge selection of really cool solar panels from
              world-famous brands
              <br /> This week there are lots of cool and cheap solar panels
            </p>
            <div className="flex ">
              <div className=" w-36 h-9 text-center items-center rounded-3xl  text-white">
                <p className="hover:bg-yellow-500 w-36 h-9 text-center items-center rounded-3xl m-8   hover:text-white  pt-1 text-black">
                  Recommended
                </p>
              </div>
              <div className=" w-36 h-9 text-center items-center rounded-3xl  text-white">
                <p className="hover:bg-yellow-500 w-36 h-9 text-center items-center rounded-3xl m-8 text-white hover:text-white text-center items-center pt-1 text-black">
                  Trending
                </p>
              </div>
              <div className=" w-36 h-9 text-center items-center rounded-3xl  text-white">
                <p className="hover:bg-yellow-500 w-36 h-9 text-center items-center rounded-3xl m-8 text-white hover:text-white text-center items-center pt-1 text-black">
                  frequently visited
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="flex items-center justify-center flex-wrap">
          <div className="c">
            <div className="min-w-[378px] min-h-[494px] m-9 pt-0 bg-white  rounded-b-3xl">
              <div className="min-w-[378px] min-h-[272px]  bg-slate-300 rounded-t-3xl"><img className="h-9 " src={rate} alt="" /></div>
              <h1 className="text-xl m-6 font-bold">SuryaNo 23</h1>
              <p className="m-6 text-wrap text-sm">
                Very cool solar panel with absorption capacity up to
                <br /> 200 watts
              </p>
              <div className=" flex items-center gap-32 mt-8 m-6">
                <h1 className="font-bold text-xl">$70.500,00</h1>
                <button className="bg-yellow-500 min-w-[80px] min-h-[30px] text-white rounded-3xl">
                  BUY
                </button>
              </div>
            </div>
          </div>
          <div className="c">
            <div className="min-w-[378px] min-h-[494px] m-9 pt-0 bg-white  rounded-b-3xl">
              <div className="min-w-[378px] min-h-[272px]  bg-slate-300 rounded-t-3xl"><img className="h-9 " src={rate} alt="" /></div>
              <h1 className="text-xl m-6 font-bold">SuryaNo 23</h1>
              <p className="m-6 text-wrap text-sm">
                Very cool solar panel with absorption capacity up to
                <br /> 200 watts
              </p>
              <div className=" flex items-center gap-32 mt-8 m-6">
                <h1 className="font-bold text-xl">$70.500,00</h1>
                <button className="bg-yellow-500 min-w-[80px] min-h-[30px] text-white rounded-3xl">
                  BUY
                </button>
              </div>
            </div>
          </div>
          
        </div>
      </div>
      <Footer />
    </>
  );
}

export default Product;
