// src/components/ResponsiveWrapper.js
import React from 'react';
import './ResponsiveWrapper.css'; // Import CSS file for styling

const ResponsiveWrapper = ({ children }) => {
  return <div className="responsive-wrapper">{children}</div>;
};

export default ResponsiveWrapper;
