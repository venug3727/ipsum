// src/pages/ContactPage.jsx
import React from "react";
import Header from "./Header";
import Footer from "./Footer";

const Home = () => {
  return (
    <>
      <Header />
      <div className="flex mt-10 flex-col items-center justify-evenly flex-wrap font-sans">
        <div className="flex justify-center items-center gap-[90px] text-center mb-8">
          <div>
            <h1 className="text-2xl font-semibold">
              Own Your Free Electricity
              <br />
              With Solar Panels Energy
            </h1>
          </div>
          <div className="ml-[90px] font-light">
            <p className="text-gray-600">
              We supply homes and businesses with renewable energy solutions
              <br /> that deliver financial savings and carbon reductions
            </p>
          </div>
        </div>

        <div className="flex flex-wrap mt-10 mb-10 gap-5 justify-center items-center">
          <div className="h-[471px] w-[800px] bg-gray-400 rounded-2xl"></div>
          <div className="h-[471px] w-[288px] bg-gray-400 rounded-2xl"></div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Home;
