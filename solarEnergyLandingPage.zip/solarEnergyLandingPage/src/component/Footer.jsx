import React from "react";
import "./footer.css";
function Footer() {
  return (
    <>
      <div className="container">
        <div className="titel">
          <div className="full-log">
            <span className="first-log">Panon</span>
            <span className="sec-log">Poe</span>
            <p>
              We supply homes and businesses ith renewable energy
              <br /> solutions that deliver financial savings and carbon
              reductions
            </p>
          </div>
        </div>
        <div className="lik">
          <div className="about">
            <ul className="link">
              <h3>About</h3>
              <li>Company</li>
              
              <li>Profile</li>
              <li>Solar Energy</li>
            </ul>
          </div>
          <div className="res">
            <ul className="link">
              <h3>Resources</h3>
              <li>Contact</li>
              <li>FAQ</li>
              <li>features</li>
            </ul>
          </div>
          <div className="legal">
            <ul className="link">
              <h3>Legal</h3>
              <li>Privecy Policy</li>
              <li>Terms and Conditions</li>
              <li>Disclamer</li>
            </ul>
          </div>
        </div>
      </div>
    </>
  );
}

export default Footer;
