import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import air from "./images/image.png";
import free from "./images/image copy.png";
import price from "./images/image copy 2.png";

function Features() {
  return (
    <>
      <div>
        <Header />
        <div className="flex flex-col mt-10 justify-center items-center font-sans">
          <div className="flex flex-wrap items-center gap-[200px] text-center mb-8">
            <div>
              <h1 className="text-2xl font-semibold">
                The Best Service And Many
                <br />
                Features For You
              </h1>
            </div>
            <div>
              <p className="text-gray-600">
                We will help you through ordering renewable solar energy from us
                <br />
                and ready to be delivered and don't worry it's free
              </p>
            </div>
          </div>
          <div className="flex flex-wrap mt-12 mb-12">
            <div className="flex flex-col gap-12 items-start">
              <div className="flex gap-5 items-center">
                <div className="h-12 w-12 bg-yellow-500 rounded-full flex items-center justify-center">
                  <img src={air} alt="" className="h-8 w-8" />
                </div>
                <div>
                  <h3 className="text-lg font-medium">Reduce Air Pollution</h3>
                  <p className="text-gray-600 -mt-2">
                    Solar energy can help reduce air pollution in the environment
                  </p>
                </div>
              </div>

              <div className="flex gap-5 items-center">
                <div className="h-12 w-12 bg-yellow-500 rounded-full flex items-center justify-center">
                  <img src={free} alt="" className="h-8 w-8" />
                </div>
                <div>
                  <h3 className="text-lg font-medium">Free Worldwide Shipping</h3>
                  <p className="text-gray-600 -mt-2">
                    Free shipping of solar panels throughout Indonesia
                  </p>
                </div>
              </div>

              <div className="flex gap-5 items-center">
                <div className="h-12 w-12 bg-yellow-500 rounded-full flex items-center justify-center">
                  <img src={price} alt="" className="h-8 w-8" />
                </div>
                <div>
                  <h3 className="text-lg font-medium">Best Price Offer</h3>
                  <p className="text-gray-600 -mt-2">
                    Very cheap prices that can be reached by all people
                  </p>
                </div>
              </div>
            </div>

            <div className="h-[407px] w-[535px] rounded-2xl bg-gray-400 ml-10"></div>
          </div>
        </div>
        <Footer />
      </div>
    </>
  );
}

export default Features;
