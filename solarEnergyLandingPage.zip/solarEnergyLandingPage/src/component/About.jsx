import React from "react";
import './About.css';
import Header from './Header';
import Footer from './Footer';
function About() {
  return (
    <>
    <div>
        <Header />
        <div className="about-container">
        <h1>About Us</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed vel malesuada lectus. Nulla facilisi. Sed tristique, felis at vulputate dictum, justo ligula posuere tellus, non malesuada tellus velit vel urna. Quisque consectetur, mi ac consectetur fermentum, justo nunc cursus nunc, sed scelerisque ipsum velit vel urna. Nulla facilisi. Sed tristique, felis at vulputate dictum, justo ligula posuere tellus, non malesuada tellus velit vel urna. Quisque consectetur, mi ac consectetur fermentum, justo nunc cursus nunc, sed scelerisque ipsum velit vel urna.</p>
        </div>
        <Footer />
    </div>
    
    </>
  );
}

export default About;
