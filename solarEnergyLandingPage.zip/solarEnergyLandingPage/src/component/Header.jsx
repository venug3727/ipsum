// src/components/Header.jsx
import React, { useState } from 'react';
import './Header.css'; // Import the CSS file for styling

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="header">
      <div className="logo">
        <span className="logo-part1"><a href="/">Panon</a></span><span className="logo-part2">Poe</span>
      </div>
      <nav className={`nav ${isMenuOpen ? 'nav--open' : ''}`}>
        <ul className="nav-list">
          <li className="nav-item"><a href="/featuers">Features</a></li>
          <li className="nav-item"><a href="/product">Product</a></li>
          <li className="nav-item"><a href="/">Solar</a></li>
          <li className="nav-item"><a href="/">About</a></li>
          <li className="nav-item"><a href="/faq">FAQ</a></li>
        </ul>
      </nav>
      <button className="booking-btn">Booking Now</button>
      <div className="menu-icon" onClick={toggleMenu}>
        {/* Simple Hamburger Icon */}
        <span className="bar"></span>
        <span className="bar"></span>
        <span className="bar"></span>
      </div>
    </header>
  );
};

export default Header;
