import "./facts.css";

function Facts() {
  return (
    <div className="containerfacts">
      <div className="heads">
        <h1>How about some<br /> fact number<br /> about us</h1>
      </div>
      <div className="cont">
        
        <div className="numbers">
          <h1>12.8K</h1>
          <h1>375K</h1>
          <h1>19.2K</h1>
        </div>
        <div className="texts">
          <p>Years Experiance</p>
          <p>work Completed</p>
          <p>Client Satisfied</p>
        </div>

        <p className="pp">
            Lorem Ipsum is simply dummy text of the printing and typesetting industry.<br/>Lorem ipsum has been the industry standard dummy text ever since the 1500s.
        </p>
        <div className="see">
            <p>see our works</p>
        
        </div>
      </div>
    </div>
  );
}

export default Facts;
