import React from 'react';
import './ourWork.css';

const OurWorks = () => {
  return (
    <section className="our-works">
      <div className="our-works-content">
        <h2>Our Works</h2>
        <p>Leverage agile frameworks to provide a robust synopsis for high level overviews.</p>
        <button className="get-started-btn">Get Started</button>
      </div>
      <div className="works-grid">
        <div className="work-item highlighted">
          <h5>UI/UX & Dev</h5>
          <h3>Odading Market eCommerce Website Design and Development</h3>
          <a href="#" className="read-more">Read More &rarr;</a>
        </div>
        <div className="work-item"></div>
        <div className="work-item"></div>
        <div className="work-item"></div>
        <div className="work-item"></div>
        <div className="work-item"></div>
      </div>
    </section>
  );
};

export default OurWorks;
