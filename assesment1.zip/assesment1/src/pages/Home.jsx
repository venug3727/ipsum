import React from 'react';
import './home.css';

function Home() {
  return (
    <div className="hero-section">
      <header className="navbar">
        <img src="logo.png" alt="Ipsum" className="logo" />
        <nav className="nav-links">
          <a href="#" className="active">Home</a>
          <a href="#about">About</a>
          <a href="#ourworks">Services</a>
          <a href="#howits">How it Works</a>
          <a href="#contact">Contact Us</a>
          <a href="#team">Our Team</a>
          <a href="#facts">Facts</a>
          <a href="#news">News</a>
          <a href="#footer">Footer</a>
        </nav>
        <button className="cta-button">Let's Talk</button>
      </header>

      <div className="hero-content">
        <div className="hero-text">
          <h1>Creative Design and Development for your product</h1>
          <p>Helped more than 200+ startups to develop their website</p>
          <button className="get-started-button">Get Started</button>
          <div className="clients-logos">
            <img src="company1.png" alt="Company Logo" />
            <img src="company2.png" alt="Company Logo" />
            <img src="company3.png" alt="Company Logo" />
          </div>
        </div>
        <div className="hero-images">
          <div className="main-image"></div>
          <div className="side-images">
            <div className="side-image small"></div>
            <div className="side-image medium"></div>
            <div className="side-image large"></div>
          </div>
        </div>
      </div>

      <footer className="hero-footer">
        <div className="social-media">
          <span>Li</span>
          <span>Ig</span>
          <span>Tw</span>
          <span>Dr</span>
          <span>Be</span>
        </div>
        <div className="contact-info">
          <span>Odading Street</span>
          <span>+62 8787 8787</span>
        </div>
      </footer>
    </div>
  );
}

export default Home;
