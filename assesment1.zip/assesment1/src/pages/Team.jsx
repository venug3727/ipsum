import React from "react";
import "./team.css";
import soc from './images/soc.png';

function Team() {
  return (
    <div className="team-section">
      <div className="hhh">
        <h2>Meet Our Team</h2>
        <div className="navigation">
          <button className="nav-button">←</button>
          <button className="nav-button">→</button>
        </div>
      </div>


      <div className="cards">
        <div className="sing-card">
            <div className="photo">

            </div>
            <div className="disc">
                <h3>John H Doe</h3>
                <p>CEO</p>
                <img  src={soc} />
                
            </div>
        </div>

        <div className="oth-card">
            <div className="phot">

            </div>
            <div className="dic">
                <h3>Emma Russel</h3>
                <p>Creative Director</p>
                
                
            </div>
        </div>
        <div className="oth-card">
            <div className="phot">

            </div>
            <div className="dic">
                <h3>Michael Angelo</h3>
                <p>Senior Graphic Designer</p>
                
                
            </div>
        </div>
        <div className="oth-card">
            <div className="phot">

            </div>
            <div className="dic">
                <h3>Donatello</h3>
                <p>UI/UX Designer</p>
                
                
            </div>
        </div>
        <div className="oth-card">
            <div className="phot">

            </div>
            <div className="dic">
                <h3>John H Doe</h3>
                <p>CEO</p>
                
                
            </div>
        </div>
       
      </div>
    </div>
  );
}

export default Team;
