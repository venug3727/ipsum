import React from 'react';
import './how.css';

function HowItWorks() {
  return (
    <div className="how-it-works">
      <h1 className="title">How it Works</h1>
      <div className="cards-container">
        <WorkCard
          title="UI/UX"
          description="Make your website design / mobile application design more colorful and give a cool impression on the eyes of the user"
          icon="👜"
          backgroundColor="#1E3A5F"
          textColor="#FFFFFF"
          actionTextColor="#FF5A5F"
        />
        <WorkCard
          title="Development"
          description="Create customizable illustrations with attractive designs that are made visually through high creativity"
          icon="🔊"
          backgroundColor="#F5F7FA"
          textColor="#000000"
          actionTextColor="#FF5A5F"
        />
        <WorkCard
          title="Database Security"
          description="Create 2d / 3d video animation in a short period of time designed to promote a company product"
          icon="🔊"
          backgroundColor="#F5F7FA"
          textColor="#000000"
          actionTextColor="#FF5A5F"
        />
      </div>
    </div>
  );
}

function WorkCard({ title, description, icon, backgroundColor, textColor, actionTextColor }) {
  return (
    <div className="work-card" style={{ backgroundColor: backgroundColor }}>
      <div className="icon" style={{ color: actionTextColor }}>{icon}</div>
      <h2 className="card-title" style={{ color: textColor }}>{title}</h2>
      <p className="card-description" style={{ color: textColor }}>{description}</p>
      <a href="#" className="explore-link" style={{ color: actionTextColor }}>
        Explore <span className="arrow">→</span>
      </a>
    </div>
  );
}

export default HowItWorks;
