import React from 'react';
import './News.css';

function NewsPage() {
  return (
    <div className="news-page">
      <h1 className="title">Our Latest News</h1>
      <div className="news-container">
        <div className="news1">
        <NewsCard
          title="How to make a website look more attractive with illustrations"
          description="Leverage agile frameworks to provide a robust synopsis for high level overviews."
          backgroundColor="#1E3A5F"
          textColor="#FFFFFF"
          actionTextColor="#FF5A5F"
        />
        </div>
        < div className="news1">
        <NewsCard
          title="8 Rules of Thumb in UI Design"
          description=""
          backgroundColor="white"
          textColor="#000000"
          actionTextColor="#FF5A5F"
        />
        </div>

        < div className="news1">
        <NewsCard
          title="How to build strong portfolio and get a Job in UI/UX"
          description=""
          backgroundColor="white"
          textColor="#000000"
          actionTextColor="#FF5A5F"
        />
        </div>
      </div>
    </div>
  );
}

function NewsCard({ title, description, backgroundColor, textColor, actionTextColor }) {
  return (
    <div className="news-card" style={{ backgroundColor: backgroundColor }}>
      <h2 className="news-title" style={{ color: textColor }}>{title}</h2>
      {description && (
        <p className="news-description" style={{ color: textColor }}>{description}</p>
      )}
      <a href="#" className="read-more" style={{ color: actionTextColor }}>
        Read More
      </a>
    </div>
  );
}

export default NewsPage;
