import React from 'react';
import './about.css';

const StatisticSection = () => {
  return (
    <div className="statistic-section">
      <h2>Our Statistic</h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
      <div className="stats">
        <div className="stat-item">
          <span className="stat-number">489</span>
          <span className="stat-label">Happy Client</span>
        </div>
        <div className="stat-item">
          <span className="stat-number">325</span>
          <span className="stat-label">Project Done</span>
        </div>
      </div>
      <div className="works-section">
        <h2>Wanna see more our works?</h2>
        <p>Let's talk with us and more explore how we doing our works.</p>
        <button className="explore-button">Explore</button>
        <div className="works-thumbnails">
          <div className="thumbnail"></div>
          <div className="thumbnail"></div>
          <div className="thumbnail"></div>
        </div>
      </div>
    </div>
  );
};

export default StatisticSection;
