import React from "react";
import "./Footer.css";

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-column">
          <h2 className="footer-title">tanahstudio</h2>
          <ul>
            <li>📍 8819 Ohio St. South Gate, CA 90280</li>
            <li>📧 Ourstudio@hello.com</li>
            <li>📞 +1 386-688-3295</li>
          </ul>
        </div>
        <div className="footer-column">
          <h3 className="footer-heading">Service</h3>
          <ul>
            <li>UI/UX Design</li>
            <li>Mobile Dev</li>
            <li>IT Consultancy</li>
            <li>Web Dev</li>
            <li>Development</li>
            <li>QA Testing</li>
          </ul>
        </div>
        <div className="footer-column">
          <h3 className="footer-heading">Company</h3>
          <ul>
            <li>Service</li>
            <li>Features</li>
            <li>Our Team</li>
            <li>Portfolio</li>
            <li>Blog</li>
            <li>Contact Us</li>
          </ul>
        </div>
        <div className="footer-column">
          <h3 className="footer-heading">Our Social Media</h3>
          <ul>
            <li>Dribbble</li>
            <li>Behance</li>
            <li>Medium</li>
            <li>Instagram</li>
            <li>Facebook</li>
            <li>Twitter</li>
          </ul>
        </div>
        <div className="footer-column">
          <h3 className="footer-heading">Join a Newsletter</h3>
          <h3 >Your Email</h3>
          <form className="newsletter-form">
            <input type="email" placeholder="Enter Your Email" />
            <button type="submit" className="send-button">
              Send
            </button>
          </form>
          <div className="footer-copyright">Copyright Tanah Air Studio</div>
        </div>
      </div>
      
    </footer>
  );
}

export default Footer;
