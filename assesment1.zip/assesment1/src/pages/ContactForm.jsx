import React, { useState } from "react";
import "./ContactForm.css";

function ContactForm() {
  return (
    <div className="contact-form">
      <h1>Get in Touch</h1>
      <p>
        Have a project in mind thet you think we'd be a great fit for it?
        <br />
        We'd love to know what you're thinking
      </p>
      <div className="iput">
        <div className="name">
          <h3>Full Name</h3>
          <input type="text" placeholder="Input your full name here" />
        </div>
        <div className="name">
          <h3>Email Address</h3>
          <input type="email" placeholder="Input your email address here" />
        </div>
      </div>

      <div className="sub">
        <h2> Subject</h2>
        <div className="in">
          <div className="subj">
            <input type="radio" name="exampl" placeholder="option" /> Illstration
          </div>
          <div className="subj">
            <input type="radio" name="exampl" placeholder="option" /> Web design
          </div>
          <div className="subj">
            <input type="radio" name="exampl" placeholder="option" /> Mobile design
          </div>
        </div>
        <div className="in">
        <div className="subj">
            <input type="radio" name="exampl" placeholder="option" /> Development
          </div>
          <div className="subj">
            <input type="radio" name="exampl" placeholder="option" /> Motion Graphic 
          </div>
          <div className="subj">
            <input type="radio" name="exampl" placeholder="option" /> Others
          </div>
        </div>
      </div>

      <div className="mess">
        <h2> Messages</h2>
        <textarea placeholder="Write your messages here" />
      </div>

      <div className="bbt">
        <button>Submit</button>
      </div>
    </div>
  );
}

export default ContactForm;
