import Home from "./pages/Home";
import Sec from "./pages/Howits";
import Thr from "./pages/About";
import "./App.css";
import { HashRouter, Routes, Route } from "react-router-dom";
import Howits from "./pages/Howits";
import About from "./pages/About";
import OurWorks from "./pages/Ourworks";
import Facts from "./pages/Facts";
import Team from "./pages/Team";
import ContactForm from "./pages/ContactForm";
import Footer from "./pages/Footer";
import News from "./pages/News";
function App() {
  return (
    <>
      <HashRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/howits" element={<Howits />} />
          <Route path="/ourworks" element={<OurWorks />} />
          <Route path="/facts" element={<Facts />} />
          <Route path="/team" element={<Team />} />
          <Route path="/contact" element={<ContactForm />} />
          <Route path="/About" element={<About />} />
          <Route path="/footer" element={<Footer />} />
          <Route path="/news" element={<News />} />
        </Routes>
      </HashRouter>
    </>
  );
}

export default App;
